# Group Details
1. Ashutosh Kumar Singh - 19CS30008
2. Neha Dalmia - 19CS30055
3. Nisarg Upadhyaya - 19CS30031
4. Parth Jindal - 19CS30033

# Organisation

The code for each part is present in the respective directory. Each directory has 3 subdirectories:
1. appcode: contains the application code which runs a terminal application to interact with the blockchain
2. chaincode: the hyperledger fabric code handling the contracts
3. setup: contains the scripts to setup and start the blockchain (not included in the zip, see initial setup instructions)
4. run.sh: script to start the blockchain

# Initial setup

1. Download the fabric-samples repo with the fabric binaries.
2. Copy the `bin, config, and test-network` folders inside the `setup` folder of each part.
3. Copy `run.sh` script inside the `test-network` directory.


# Instructions

To start the blockchain change directory to `<part>/setup/test-network` and run
```
chmod +x run.sh
./run.sh
```
Then change directory to `<part>/appcode/<org>` for each organisation and run
```
npm install
npm start
```
This will start the application for each organisation.
