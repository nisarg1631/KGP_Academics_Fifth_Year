'use strict';

const marketOps = require('./lib/market');

module.exports.MarketOps = marketOps;
module.exports.contracts = [marketOps];
