'use strict';

const { Gateway, Wallets } = require('fabric-network');
const FabricCAServices = require('fabric-ca-client');
const path = require('path');
const readline = require('readline');
const { buildCAClient, registerAndEnrollUser, enrollAdmin } = require('../CAUtil.js');
const { buildCCPOrg2, buildWallet } = require('../AppUtil.js');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const myChannel = 'mychannel';
const myChaincodeName = 'mychaincode';

const org2PrivateCollectionName = 'Org2MSPPrivateCollection';
const mspOrg2 = 'Org2MSP';
const Org2UserId = 'appUser2';

const RED = '\x1b[31m\n';
const RESET = '\x1b[0m';

function askQuestion(question) {
    return new Promise((resolve) => {
        rl.question(question, (answer) => {
            resolve(answer);
        });
    });
}

function prettyJSONString(inputString) {
    if (inputString) {
        return JSON.stringify(JSON.parse(inputString), null, 2);
    }
    else {
        return inputString;
    }
}

async function initContractFromOrg2Identity() {
    console.log('\n--> Fabric client user & Gateway init: Using Org2 identity to Org2 Peer');
    const ccpOrg2 = buildCCPOrg2();
    const caOrg2Client = buildCAClient(FabricCAServices, ccpOrg2, 'ca.org2.example.com');

    const walletPathOrg2 = path.join(__dirname, 'wallet/org2');
    const walletOrg2 = await buildWallet(Wallets, walletPathOrg2);

    // await enrollAdmin(caOrg2Client, walletOrg2, mspOrg2);
    // await registerAndEnrollUser(caOrg2Client, walletOrg2, mspOrg2, Org2UserId, 'org2.department1');

    try {
        // Create a new gateway for connecting to Org's peer node.
        const gatewayOrg2 = new Gateway();
        await gatewayOrg2.connect(ccpOrg2,
            { wallet: walletOrg2, identity: Org2UserId, discovery: { enabled: true, asLocalhost: true } });

        return gatewayOrg2;
    } catch (error) {
        console.error(`Error in connecting to gateway: ${error}`);
        process.exit(1);
    }
}

async function main() {
    try {

        /** ******* Fabric client init: Using Org2 identity to Org2 Peer ********** */
        const gatewayOrg2 = await initContractFromOrg2Identity();
        const networkOrg2 = await gatewayOrg2.getNetwork(myChannel);
        const contractOrg2 = networkOrg2.getContract(myChaincodeName);
        // Since this sample chaincode uses, Private Data Collection level endorsement policy, addDiscoveryInterest
        // scopes the discovery service further to use the endorsement policies of collections, if any
        contractOrg2.addDiscoveryInterest({ name: myChaincodeName, collectionNames: [org2PrivateCollectionName] });
        try {
            await contractOrg2.submitTransaction('InitLedger');
            while (true) {
                const command = await askQuestion('Enter a command (ADD_MONEY, ADD_ITEM, QUERY_BALANCE, GET_ITEM, or EXIT): ');
    
                if (command === 'EXIT') {
                    console.log('Exiting the application...');
                    break;
                }
                
                try {
                    if (command === 'ADD_MONEY') {
                        // Implement ADD_MONEY logic
                        const amount = parseInt(await askQuestion('Enter amount: ')); // Amount to add
                        const response = await contractOrg2.submitTransaction('AddBalance', amount);
                        console.log(`Updated balance is ${response}\n`);
                    } else if (command === 'ADD_ITEM') {
                        // Implement ADD_ITEM logic
                        const itemName = await askQuestion('Enter unique name: ');
                        const itemCount = parseInt(await askQuestion('Enter count: '));
                        const itemPrice = parseInt(await askQuestion('Enter price: '));
                        let statefulTxn = contractOrg2.createTransaction('AddItem');
                        let tmapData = Buffer.from(JSON.stringify({ name: itemName, count: itemCount, price: itemPrice }));
                        statefulTxn.setTransient({
                            asset_properties: tmapData
                        });
                        await statefulTxn.submit();
                        console.log(`Item added successfully\n`);
                    } else if (command === 'QUERY_BALANCE') {
                        // Implement QUERY_BALANCE logic
                        const response = await contractOrg2.evaluateTransaction('GetBalance');
                        console.log(`Balance is ${response}\n`);
                    } else if (command === 'GET_ITEM') {
                        // Implement GET_ITEM logic
                        const itemName = await askQuestion('Enter item name: ');
                        const response = await contractOrg2.evaluateTransaction('GetItem', itemName);
                        if (response.length !== 0) {
                            console.log(prettyJSONString(response) + '\n');
                        }
                        else {
                            console.log(`${itemName} not found in inventory\n`)
                        }
                    } else {
                        console.error('Invalid command. Supported commands: ADD_MONEY, ADD_ITEM, QUERY_BALANCE, GET_ITEM, EXIT\n');
                    }
                } catch(error) {
                    console.error(`Error in transaction: ${error}`);
                    if (error.stack) {
                        console.error(error.stack);
                    }
                    console.error('\n')
                }
            }
            // // Sample transactions are listed below
            // // Add few sample Assets & transfers one of the asset from Org1 to Org2 as the new owner
            // let randomNumber = Math.floor(Math.random() * 1000) + 1;
            // // use a random key so that we can run multiple times
            // let assetID1 = `asset${randomNumber}`;
            // let assetID2 = `asset${randomNumber + 1}`;
            // const assetType = 'ValuableAsset';
            // let result;
            // let asset1Data = { objectType: assetType, assetID: assetID1, color: 'green', size: 20, appraisedValue: 100 };
            // let asset2Data = { objectType: assetType, assetID: assetID2, color: 'blue', size: 35, appraisedValue: 727 };

            // console.log('\n**************** As Org1 Client ****************');
            // console.log('Adding Assets to work with:\n--> Submit Transaction: CreateAsset ' + assetID1);
            // let statefulTxn = contractOrg1.createTransaction('CreateAsset');
            // // if you need to customize endorsement to specific set of Orgs, use setEndorsingOrganizations
            // // statefulTxn.setEndorsingOrganizations(mspOrg1);
            // let tmapData = Buffer.from(JSON.stringify(asset1Data));
            // statefulTxn.setTransient({
            //     asset_properties: tmapData
            // });
            // result = await statefulTxn.submit();

            // // Add asset2
            // console.log('\n--> Submit Transaction: CreateAsset ' + assetID2);
            // statefulTxn = contractOrg1.createTransaction('CreateAsset');
            // tmapData = Buffer.from(JSON.stringify(asset2Data));
            // statefulTxn.setTransient({
            //     asset_properties: tmapData
            // });
            // result = await statefulTxn.submit();


            // console.log('\n--> Evaluate Transaction: GetAssetByRange asset0-asset9');
            // // GetAssetByRange returns assets on the ledger with ID in the range of startKey (inclusive) and endKey (exclusive)
            // result = await contractOrg1.evaluateTransaction('GetAssetByRange', 'asset0', 'asset9');
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // if (!result || result.length === 0) {
            //     doFail('recieved empty query list for GetAssetByRange');
            // }
            // console.log('\n--> Evaluate Transaction: ReadAssetPrivateDetails from ' + org1PrivateCollectionName);
            // // ReadAssetPrivateDetails reads data from Org's private collection. Args: collectionName, assetID
            // result = await contractOrg1.evaluateTransaction('ReadAssetPrivateDetails', org1PrivateCollectionName, assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // verifyAssetPrivateDetails(result, assetID1, 100);

            // // Attempt Transfer the asset to Org2 , without Org2 adding AgreeToTransfer //
            // // Transaction should return an error: "failed transfer verification ..."
            // let buyerDetails = { assetID: assetID1, buyerMSP: mspOrg2 };
            // try {
            //     console.log('\n--> Attempt Submit Transaction: TransferAsset ' + assetID1);
            //     statefulTxn = contractOrg1.createTransaction('TransferAsset');
            //     tmapData = Buffer.from(JSON.stringify(buyerDetails));
            //     statefulTxn.setTransient({
            //         asset_owner: tmapData
            //     });
            //     result = await statefulTxn.submit();
            //     console.log('******** FAILED: above operation expected to return an error');
            // } catch (error) {
            //     console.log(`   Successfully caught the error: \n    ${error}`);
            // }
            // console.log('\n~~~~~~~~~~~~~~~~ As Org2 Client ~~~~~~~~~~~~~~~~');
            // console.log('\n--> Evaluate Transaction: ReadAsset ' + assetID1);
            // result = await contractOrg2.evaluateTransaction('ReadAsset', assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // verifyAssetData(mspOrg2, result, assetID1, 'green', 20, Org1UserId);


            // // Org2 cannot ReadAssetPrivateDetails from Org1's private collection due to Collection policy
            // //    Will fail: await contractOrg2.evaluateTransaction('ReadAssetPrivateDetails', org1PrivateCollectionName, assetID1);

            // // Buyer from Org2 agrees to buy the asset assetID1 //
            // // To purchase the asset, the buyer needs to agree to the same value as the asset owner
            // let dataForAgreement = { assetID: assetID1, appraisedValue: 100 };
            // console.log('\n--> Submit Transaction: AgreeToTransfer payload ' + JSON.stringify(dataForAgreement));
            // statefulTxn = contractOrg2.createTransaction('AgreeToTransfer');
            // tmapData = Buffer.from(JSON.stringify(dataForAgreement));
            // statefulTxn.setTransient({
            //     asset_value: tmapData
            // });
            // result = await statefulTxn.submit();

            // //Buyer can withdraw the Agreement, using DeleteTranferAgreement
            // /*statefulTxn = contractOrg2.createTransaction('DeleteTranferAgreement');
            // statefulTxn.setEndorsingOrganizations(mspOrg2);
            // let dataForDeleteAgreement = { assetID: assetID1 };
            // tmapData = Buffer.from(JSON.stringify(dataForDeleteAgreement));
            // statefulTxn.setTransient({
            //     agreement_delete: tmapData
            // });
            // result = await statefulTxn.submit();*/

            // console.log('\n**************** As Org1 Client ****************');
            // // All members can send txn ReadTransferAgreement, set by Org2 above
            // console.log('\n--> Evaluate Transaction: ReadTransferAgreement ' + assetID1);
            // result = await contractOrg1.evaluateTransaction('ReadTransferAgreement', assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);

            // // Transfer the asset to Org2 //
            // // To transfer the asset, the owner needs to pass the MSP ID of new asset owner, and initiate the transfer
            // console.log('\n--> Submit Transaction: TransferAsset ' + assetID1);

            // statefulTxn = contractOrg1.createTransaction('TransferAsset');
            // tmapData = Buffer.from(JSON.stringify(buyerDetails));
            // statefulTxn.setTransient({
            //     asset_owner: tmapData
            // });
            // result = await statefulTxn.submit();

            // // Again ReadAsset : results will show that the buyer identity now owns the asset:
            // console.log('\n--> Evaluate Transaction: ReadAsset ' + assetID1);
            // result = await contractOrg1.evaluateTransaction('ReadAsset', assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // verifyAssetData(mspOrg1, result, assetID1, 'green', 20, Org2UserId);

            // // Confirm that transfer removed the private details from the Org1 collection:
            // console.log('\n--> Evaluate Transaction: ReadAssetPrivateDetails');
            // // ReadAssetPrivateDetails reads data from Org's private collection: Should return empty
            // result = await contractOrg1.evaluateTransaction('ReadAssetPrivateDetails', org1PrivateCollectionName, assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // if (result && result.length > 0) {
            //     doFail('Expected empty data from ReadAssetPrivateDetails');
            // }
            // console.log('\n--> Evaluate Transaction: ReadAsset ' + assetID2);
            // result = await contractOrg1.evaluateTransaction('ReadAsset', assetID2);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // verifyAssetData(mspOrg1, result, assetID2, 'blue', 35, Org1UserId);

            // console.log('\n********* Demo deleting asset **************');
            // let dataForDelete = { assetID: assetID2 };
            // try {
            //     // Non-owner Org2 should not be able to DeleteAsset. Expect an error from DeleteAsset
            //     console.log('--> Attempt Transaction: as Org2 DeleteAsset ' + assetID2);
            //     statefulTxn = contractOrg2.createTransaction('DeleteAsset');
            //     tmapData = Buffer.from(JSON.stringify(dataForDelete));
            //     statefulTxn.setTransient({
            //         asset_delete: tmapData
            //     });
            //     result = await statefulTxn.submit();
            //     console.log('******** FAILED : expected to return an error');
            // } catch (error) {
            //     console.log(`  Successfully caught the error: \n    ${error}`);
            // }
            // // Delete Asset2 as Org1
            // console.log('--> Submit Transaction: as Org1 DeleteAsset ' + assetID2);
            // statefulTxn = contractOrg1.createTransaction('DeleteAsset');
            // tmapData = Buffer.from(JSON.stringify(dataForDelete));
            // statefulTxn.setTransient({
            //     asset_delete: tmapData
            // });
            // result = await statefulTxn.submit();

            // console.log('\n--> Evaluate Transaction: ReadAsset ' + assetID2);
            // result = await contractOrg1.evaluateTransaction('ReadAsset', assetID2);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // if (result && result.length > 0) {
            //     doFail('Expected empty read, after asset is deleted');
            // }

            // console.log('\n~~~~~~~~~~~~~~~~ As Org2 Client ~~~~~~~~~~~~~~~~');
            // // Org2 can ReadAssetPrivateDetails: Org2 is owner, and private details exist in new owner's Collection
            // console.log('\n--> Evaluate Transaction as Org2: ReadAssetPrivateDetails ' + assetID1 + ' from ' + org2PrivateCollectionName);
            // result = await contractOrg2.evaluateTransaction('ReadAssetPrivateDetails', org2PrivateCollectionName, assetID1);
            // console.log(`<-- result: ${prettyJSONString(result.toString())}`);
            // verifyAssetPrivateDetails(result, assetID1, 100);
        } finally {
            // Disconnect from the gateway peer when all work for this client identity is complete
            gatewayOrg2.disconnect();
            rl.close();
        }
    } catch (error) {
        console.error(`Error in transaction: ${error}`);
        if (error.stack) {
            console.error(error.stack);
        }
        process.exit(1);
    }
}

main();
